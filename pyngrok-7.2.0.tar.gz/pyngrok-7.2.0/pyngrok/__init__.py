__copyright__ = "Copyright (c) 2018-2024 Alex Laird"
__license__ = "MIT"
__version__ = "7.2.0"
